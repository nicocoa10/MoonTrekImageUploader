from django.db import models
from .validators import file_size
from django_resized import ResizedImageField

# Create your models here.

class Capture(models.Model):

    #Here we create the fields that our db is gonna contain for every capture(picutre)

    image = ResizedImageField(size=[600, 400], quality=100, force_format='JPEG', keep_meta=True, upload_to='pictures/', validators=[file_size]) #this is for the image
    # time= models.TimeField(auto_now=False, auto_now_add=False , blank=False)  #this is for the time
    # longitude = models.DecimalField(max_digits=9, decimal_places=6, blank=False) #this is for longitude
    # latitude = models.DecimalField(max_digits=9, decimal_places=6,blank=False)  #this is for latitude


