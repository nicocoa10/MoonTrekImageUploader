from django import forms
from .models import Capture

class CaptureForm(forms.ModelForm):
    class Meta:
        model = Capture
        fields= ('image',)
        widgets = { # Widget to customize the form attributes and allow the form to be affected by the CSS and JS files
            'image': forms.ClearableFileInput(attrs={'type': 'file', 'id': 'upload', 'name': 'document', 'onchange': 'readURL(this);'})}
