from django.contrib import admin

from .models import Capture
# Register your models here.

admin.site.register(Capture)
