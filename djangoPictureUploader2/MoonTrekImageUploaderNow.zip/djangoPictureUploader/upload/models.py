from django.db import models
from django.db.models import Model
from .validators import file_size
from django_resized import ResizedImageField


class Uploader(models.Model):
    upload_Main_Img = ResizedImageField(size=[300, 100], quality=100, force_format='JPEG', keep_meta=True, upload_to='pictures/', validators=[file_size])

# (pip install django-resized) install the library in the parenthesis (in command prompt) so resizing function works