from django import forms
from .models import *

class UploadForm(forms.ModelForm):

    class Meta:
        model = Uploader
        fields = ['upload_Main_Img']
        widgets = { # Widget to customize the form attributes and allow the form to be affected by the CSS and JS files
            'upload_Main_Img': forms.ClearableFileInput(attrs={'type': 'file', 'id': 'upload', 'name': 'document', 'onchange': 'readURL(this);'})}

# Original File Code in case it needs to be switched back<!--<div class="input-group mb-3 px-2 py-2 rounded-pill bg-white shadow-sm">-->
# <!--    <input id="upload" type="file" name="document" onchange="readURL(this);" class="form-control border-0" accept="image/*">-->
# <!--    <div class="input-group-append">-->
# <!--        <label for="upload" class="btn btn-light m-0 rounded-pill px-4"> <i class="fa fa-cloud-upload mr-2 text-muted"></i><small class="text-uppercase font-weight-bold text-muted">Choose file</small></label>-->
# <!--    </div>-->
# <!--</div>-->